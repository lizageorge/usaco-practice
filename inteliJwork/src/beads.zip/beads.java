/*
ID: liza1
LANG: JAVA
TASK: beads
*/

//https://train.usaco.org/usacogate?a=MtNe9oU2hvv
//liza1 

import java.util.*;
import java.io.*;

public class beads {
    public static void main(String[] args) throws IOException {
        BufferedReader f = new BufferedReader(new FileReader("C:\\Users\\lizag\\OneDrive\\Documents\\USACO\\USACO Training inputs\\bead.in.txt")); //TEST
//        BufferedReader f = new BufferedReader(new FileReader("beads.in")); //CONTEST
//        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("beads.out"))); //CONTEST

//        StringTokenizer st;

        int n = Integer.parseInt(f.readLine());
        String inputS = f.readLine();
        char[] input = inputS.toCharArray();
//        System.out.println(inputS);

        int output = 0;
        int testOutput = 0;
        int outputRight = 0;
        int outputLeft = 0;


        for(int i = 0; i < n; i++){ //testing every starting index

            //test going right
            outputRight = 1;

            char fbr = input[i];

            outerloopR:
            for(int j = 1; j < n; j++){
                char sb = input[ (i + j) % n];
                if(fbr == sb || sb == 'w'){
                    outputRight++;
                }
                else {
                    System.out.println(j);
                    break outerloopR;

                }
            }


            //test going left
            outputLeft = 0;

            //if i was not given the test data, i wouldn't know to fix this...
            if(outputRight != n){
                outputLeft = 1;
                char fbl;
                if( i != 0){
                    fbl = input[i-1];
                }else{
                    fbl = input[n-1];
                }

                outerloopL:
                for(int j = n; j > 0; j--){
                    char sb = input[ Math.abs(i - j) % n];
                    if(fbl == sb || sb == 'w'){
                        outputLeft++;
                    }
                    else {
                        break outerloopL;
                    }
                }
            }


            testOutput = outputRight + outputLeft;
            if(testOutput > output){
                output  = testOutput;
            }
        }

//        output++;


//        while(f.ready()){
//
//        }

        System.out.println(outputRight);
        System.out.println(outputLeft);

        System.out.println(output); //TEST
//        out.println(output); //CONTEST
//        out.close();
    }
}
